@ echo off
REM Erdogan Tan - 21/09/2026 (nasm 3.0.2 make, tdm-gcc)

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/nasm.o asm/nasm.c

windres -I. -Iwin -DMANIFEST_FILE="win/manifest.xml"   -i win/manifest.rc -o win/manifest.o

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/error.o asm/error.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/floats.o asm/floats.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/directiv.o asm/directiv.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/pragma.o asm/pragma.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/assemble.o asm/assemble.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/labels.o asm/labels.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/parser.o asm/parser.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/preproc.o asm/preproc.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/quote.o asm/quote.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/listing.o asm/listing.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/eval.o asm/eval.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/exprlib.o asm/exprlib.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/exprdump.o asm/exprdump.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/stdscan.o asm/stdscan.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/getbool.o asm/getbool.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/strfunc.o asm/strfunc.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/segalloc.o asm/segalloc.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/rdstrnum.o asm/rdstrnum.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/srcfile.o asm/srcfile.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/directbl.o asm/directbl.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/pptok.o asm/pptok.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/tokhash.o asm/tokhash.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/uncompress.o asm/uncompress.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o macros/macros.o macros/macros.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o asm/warnings.o asm/warnings.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outform.o output/outform.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outlib.o output/outlib.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/nulldbg.o output/nulldbg.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/nullout.o output/nullout.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outbin.o output/outbin.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outaout.o output/outaout.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outcoff.o output/outcoff.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outelf.o output/outelf.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outobj.o output/outobj.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outas86.o output/outas86.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outdbg.o output/outdbg.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outieee.o output/outieee.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/outmacho.o output/outmacho.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o output/codeview.o output/codeview.c

%~dp0../mingw32/usr/bin/rm -f libasm.a

%~dp0../mingw32/usr/bin/ar cq libasm.a asm/error.o asm/floats.o asm/directiv.o asm/pragma.o asm/assemble.o asm/labels.o ^
asm/parser.o asm/preproc.o asm/quote.o asm/listing.o asm/eval.o asm/exprlib.o asm/exprdump.o asm/stdscan.o asm/getbool.o ^
asm/strfunc.o asm/segalloc.o asm/rdstrnum.o asm/srcfile.o asm/directbl.o asm/pptok.o asm/tokhash.o asm/uncompress.o ^
macros/macros.o asm/warnings.o output/outform.o output/outlib.o output/nulldbg.o output/nullout.o output/outbin.o ^
output/outaout.o output/outcoff.o output/outelf.o output/outobj.o output/outas86.o output/outdbg.o output/outieee.o ^
output/outmacho.o output/codeview.o

%~dp0../mingw32/usr/bin/ranlib libasm.a

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o stdlib/snprintf.o stdlib/snprintf.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o stdlib/vsnprintf.o stdlib/vsnprintf.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o stdlib/strlcpy.o stdlib/strlcpy.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o stdlib/strnlen.o stdlib/strnlen.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/ver.o nasmlib/ver.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/alloc.o nasmlib/alloc.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/asprintf.o nasmlib/asprintf.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/crc32b.o nasmlib/crc32b.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/crc64.o nasmlib/crc64.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/md5c.o nasmlib/md5c.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/string.o nasmlib/string.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/nctype.o nasmlib/nctype.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/file.o nasmlib/file.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/fileio.o nasmlib/fileio.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/mmap.o nasmlib/mmap.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/realpath.o nasmlib/realpath.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/path.o nasmlib/path.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/ilog2.o nasmlib/ilog2.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/numstr.o nasmlib/numstr.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/rlimit.o nasmlib/rlimit.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/zerobuf.o nasmlib/zerobuf.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/bsi.o nasmlib/bsi.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/rbtree.o nasmlib/rbtree.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/hashtbl.o nasmlib/hashtbl.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/raa.o nasmlib/raa.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/saa.o nasmlib/saa.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/strlist.o nasmlib/strlist.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/perfhash.o nasmlib/perfhash.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/badenum.o nasmlib/badenum.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o nasmlib/readnum.o nasmlib/readnum.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o common/common.o common/common.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o common/errstubs.o common/errstubs.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/insnsa.o x86/insnsa.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/insnsb.o x86/insnsb.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/insnsn.o x86/insnsn.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/regs.o x86/regs.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/regvals.o x86/regvals.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/regflags.o x86/regflags.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/iflag.o x86/iflag.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/adler32.o zlib/adler32.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/crc32.o zlib/crc32.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/infback.o zlib/infback.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/inffast.o zlib/inffast.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/inflate.o zlib/inflate.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/inftrees.o zlib/inftrees.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o zlib/zutil.o zlib/zutil.c

%~dp0../mingw32/usr/bin/rm -f libnasm.a

%~dp0../mingw32/usr/bin/ar cq libnasm.a stdlib/snprintf.o stdlib/vsnprintf.o stdlib/strlcpy.o stdlib/strnlen.o nasmlib/ver.o ^ nasmlib/alloc.o nasmlib/asprintf.o nasmlib/crc32b.o nasmlib/crc64.o nasmlib/md5c.o nasmlib/string.o nasmlib/nctype.o ^
nasmlib/file.o nasmlib/fileio.o nasmlib/mmap.o nasmlib/realpath.o nasmlib/path.o nasmlib/ilog2.o nasmlib/numstr.o ^
nasmlib/rlimit.o nasmlib/zerobuf.o nasmlib/bsi.o nasmlib/rbtree.o nasmlib/hashtbl.o nasmlib/raa.o nasmlib/saa.o ^
nasmlib/strlist.o nasmlib/perfhash.o nasmlib/badenum.o nasmlib/readnum.o common/common.o common/errstubs.o x86/insnsa.o ^
x86/insnsb.o x86/insnsn.o x86/regs.o x86/regvals.o x86/regflags.o x86/iflag.o zlib/adler32.o zlib/crc32.o zlib/infback.o ^
zlib/inffast.o zlib/inflate.o zlib/inftrees.o zlib/zutil.o

%~dp0../mingw32/usr/bin/ranlib libnasm.a

gcc -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -Wl,--as-needed -Wl,--gc-sections ^
-o nasm.exe asm/nasm.o win/manifest.o libasm.a libnasm.a

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o disasm/ndisasm.o disasm/ndisasm.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o disasm/disasm.o disasm/disasm.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o disasm/sync.o disasm/sync.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o disasm/prefix.o disasm/prefix.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o disasm/diserror.o disasm/diserror.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/insnsd.o x86/insnsd.c

gcc -c -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -o x86/regdis.o x86/regdis.c

del libdis.a

%~dp0../mingw32/usr/bin/rm -f libdis.a

%~dp0../mingw32/usr/bin/ar cq libdis.a disasm/disasm.o disasm/sync.o disasm/prefix.o disasm/diserror.o x86/insnsd.o x86/regdis.o

%~dp0../mingw32/usr/bin/ranlib libdis.a

gcc -Werror=attributes -g -O2 -U__STRICT_ANSI__ -ggdb3 -fwrapv -fno-common -ffunction-sections -fdata-sections ^
-fvisibility=hidden -Wall -W -pedantic -Werror=implicit -Werror=missing-braces -Werror=return-type -Werror=trigraphs ^
-Werror=pointer-arith -Werror=comment -Werror=vla -Werror=strict-prototypes -Werror=missing-prototypes ^
-Werror=missing-declarations -Wno-variadic-macros -Wno-long-long -Wno-stringop-truncation -Wno-shift-negative-value ^
-DHAVE_CONFIG_H -I. -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib  -Wl,--as-needed -Wl,--gc-sections ^
-o ndisasm.exe disasm/ndisasm.o win/manifest.o libdis.a libnasm.a

