/* 22/09/2026 - Gemini (Google AI) */

#include <sys/stat.h>

// TCC için eksik MSVCRT sembol köprüleri
int _fstat32i64(int fd, struct _stat32i64 *buf) {
    return _fstati64(fd, (struct _stati64 *)buf);
}

int _wstat32i64(const wchar_t *path, struct _stat32i64 *buf) {
    return _wstati64(path, (struct _stati64 *)buf);
}