tcc -DHAVE_CONFIG_H -I. -I../include -I../include/sys -I./include -I./x86 -I./asm -I./disasm -I./output -I./zlib -o ndisasm.exe ^
disasm/ndisasm.c disasm/disasm.c disasm/sync.c disasm/prefix.c disasm/diserror.c x86/insnsd.c x86/regdis.c ^
stdlib/snprintf.c stdlib/vsnprintf.c stdlib/strlcpy.c stdlib/strnlen.c nasmlib/ver.c nasmlib/alloc.c nasmlib/asprintf.c ^
nasmlib/crc32b.c nasmlib/crc64.c nasmlib/md5c.c nasmlib/string.c nasmlib/nctype.c nasmlib/file.c nasmlib/fileio.c nasmlib/mmap.c ^
nasmlib/realpath.c nasmlib/path.c nasmlib/ilog2.c nasmlib/numstr.c nasmlib/rlimit.c nasmlib/zerobuf.c nasmlib/bsi.c ^
nasmlib/rbtree.c nasmlib/hashtbl.c nasmlib/raa.c nasmlib/saa.c nasmlib/strlist.c nasmlib/perfhash.c nasmlib/badenum.c ^
nasmlib/readnum.c common/common.c common/errstubs.c x86/insnsa.c x86/insnsb.c x86/insnsn.c x86/regs.c x86/regvals.c ^
x86/regflags.c x86/iflag.c zlib/adler32.c zlib/crc32.c zlib/infback.c zlib/inffast.c zlib/inflate.c zlib/inftrees.c zlib/zutil.c ^
compat_stat.c


