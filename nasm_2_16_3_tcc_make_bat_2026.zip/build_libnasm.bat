@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo   TRDOS 386 - NATIVE NASM LIBC DERLEYICI
echo ====================================================

set BASE_DIR=C:\TCC
set LIBC_SRC=%BASE_DIR%\nasm
set OUT_DIR=%BASE_DIR%\nasm\libnasm
set TCC_EXE=%BASE_DIR%\tcc.exe
set CUSTOM_AR=%BASE_DIR%\nasm\ar.exe

if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

echo.
echo [1/2] C ve NASM Kodlari Saf ELF32 Object Formatinda Derleniyor...

rem --- C DOSYALARI (TCC Yerel Derleme) ---
for %%c in (snprintf strlcpy strnlen strrchrnul ver alloc asprintf
    errfile crc32 crc64 md5c string nctype file mmap ilog2 realpath path filename
    rlimit readnum numstr zerobuf bsi rbtree hashtbl raa saa strlist perfhash
    badenum common insnsa insnsb insnsd insnsn regs regvals regflags regdis disp8
    iflag error floats directiv directbl pragma assemble labels parser preproc
    quote pptok listing eval exprlib exprdump stdscan strfunc tokhash segalloc
    rdstrnum srcfile macros outform outlib legacy nulldbg nullout outbin outaout
    outcoff outelf outobj outas86 outdbg outieee outmacho codeview disasm
    sync warnings) do (
    if exist "%LIBC_SRC%\%%c.c" (
        echo   [C] -^> %%c.c
        "%TCC_EXE%" -c "%LIBC_SRC%\%%c.c" -o "%OUT_DIR%\%%c.o"
    )
)

echo.
echo [2/2] Saf nesne dosyalari Yerel C AR.EXE ile paketleniyor (libnasm.a)...
cd /d "%OUT_DIR%"
"%CUSTOM_AR%" libnasm.a *.o

echo ====================================================
echo   TAMAMLANDI: TCC uyumlu libnasm.a hazir!
echo ====================================================
pause
