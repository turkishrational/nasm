tcc -o nasm.exe ^
nasm.c snprintf.c strlcpy.c strnlen.c strrchrnul.c ver.c alloc.c asprintf.c ^
errfile.c crc32.c crc64.c md5c.c string.c nctype.c file.c mmap.c ilog2.c ^
realpath.c path.c filename.c rlimit.c readnum.c numstr.c zerobuf.c bsi.c rbtree.c ^
hashtbl.c raa.c saa.c strlist.c perfhash.c badenum.c common.c insnsa.c insnsb.c ^
insnsd.c insnsn.c regs.c regvals.c regflags.c regdis.c disp8.c iflag.c error.c ^
floats.c directiv.c directbl.c pragma.c assemble.c labels.c parser.c preproc.c ^
quote.c pptok.c listing.c eval.c exprlib.c exprdump.c stdscan.c strfunc.c tokhash.c ^
segalloc.c rdstrnum.c srcfile.c macros.c outform.c outlib.c legacy.c nulldbg.c ^
nullout.c outbin.c outaout.c outcoff.c outelf.c outobj.c outas86.c outdbg.c outieee.c ^
outmacho.c codeview.c disasm.c sync.c warnings.c
