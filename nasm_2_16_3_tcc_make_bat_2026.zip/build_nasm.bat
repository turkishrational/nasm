tcc -c nasm.c
tcc nasm.c libnasm.a -o nasm.exe -L c:\tcc\lib
tcc -c ndisasm.c
tcc ndisasm.c libnasm.a -o ndisasm.exe -L c:\tcc\lib