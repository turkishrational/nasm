tcc -o nasm.exe ^
nasm.c common.c ver.c crc64.c malloc.c errfile.c md5c.c string.c ^
file.c mmap.c ilog2.c realpath.c path.c filename.c srcfile.c ^
zerobuf.c readnum.c bsi.c rbtree.c hashtbl.c raa.c saa.c ^
strlist.c perfhash.c badenum.c strlcpy.c strnlen.c strrchrnul.c ^
insnsa.c insnsb.c insnsd.c insnsn.c regs.c regvals.c regflags.c ^
regdis.c disp8.c iflag.c error.c float.c directiv.c directbl.c ^
pragma.c assemble.c labels.c parser.c preproc.c quote.c pptok.c ^
listing.c eval.c exprlib.c exprdump.c stdscan.c strfunc.c tokhash.c ^
segalloc.c preproc-nop.c rdstrnum.c macros.c outform.c ^
outlib.c legacy.c strtbl.c nulldbg.c nullout.c outbin.c ^
outaout.c outcoff.c outelf.c outobj.c outas86.c outrdf2.c ^
outdbg.c outieee.c outmacho.c codeview.c

