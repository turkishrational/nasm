tcc -o ndisasm.exe ^
ndisasm.c disasm.c sync.c common.c ver.c malloc.c error.c string.c ^
ilog2.c hashtbl.c badenum.c strlcpy.c strnlen.c strrchrnul.c ^
insnsb.c insnsd.c insnsn.c regs.c regdis.c disp8.c iflag.c ^
regvals.c regflags.c directbl.c perfhash.c readnum.c errfile.c ^
crc64.c pptok.c tokhash.c
